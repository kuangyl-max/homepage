鼠标选中后右键：

**.ps1** 

使用powershell运行

**.cmd**

以管理员身份运行

**.ttf**

安装后需要在powershell内设置字体:

打开powershell ,点击界面右上角logo，转到 属性 ， 设置字体为Fira Code Rentia

> 如无法安装，可以管理员身份打开powershell，切换到相应目录
>
> 使用./file来执行，如`./admi_scoop_install.ps`



**.vscode** 

使用vscode打开当前文件夹（./install），会推荐安装插件；

另外，settings.json 和extension是配套的，可以复制到自己的settings.json里面，复制前建议备份

先执行scoop安装脚本， 再安装posh

可配合tool.md阅读[工具合集 | 博客 (kuangyl-max.github.io)](https://kuangyl-max.github.io/2021/10/28/tool/)

