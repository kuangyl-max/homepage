鼠标选中后右键：

**.ps1** 

使用powershell运行

**.cmd**

以管理员身份运行

**.ttf**

安装

> 如无法安装，可以管理员身份打开powershell，切换到相应目录
>
> 使用./file来执行，如`./admi_scoop_install.ps`

