Set-ExecutionPolicy Bypass
Install-Module DirColors -Scope CurrentUser
Install-Module posh-git -Scope CurrentUser
Install-Module oh-my-posh -Scope CurrentUser
scoop install terminus -g 
cat .\posh >>$PROFILE
explorer.exe .\Fira_Code_v5.2\ttf\