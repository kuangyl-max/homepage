Set-ExecutionPolicy Bypass
Install-Module DirColors -Scope CurrentUser
Install-Module posh-git -Scope CurrentUser
Install-Module PSColor -Scope CurrentUser
Install-Module -Name git-aliases -RequiredVersion 0.0.1 -AllowClobber
Install-Module oh-my-posh -Scope CurrentUser
cat .\posh >>$PROFILE
