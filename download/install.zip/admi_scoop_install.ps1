Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
iwr -useb get.scoop.sh | iex
$env:SCOOP='D:\Applications\Scoop'
[Environment]::SetEnvironmentVariable('SCOOP', $env:SCOOP, 'User')
$env:SCOOP_GLOBAL='F:\GlobalScoopApps'
[Environment]::SetEnvironmentVariable('SCOOP_GLOBAL', $env:SCOOP_GLOBAL, 'Machine')

scoop install -g  7zip
scoop install -g  axel
scoop install -g  bfg
scoop install -g  cacert
scoop install -g  cacert
scoop install -g  cloc
scoop install -g  colortool
scoop install -g  curl
scoop install -g  gawk
scoop install -g  grep
scoop install -g  maven
scoop install -g  maven
scoop install -g  nano
scoop install -g  ntop
scoop install -g  redis
scoop install -g  sed
scoop install -g  sudo
scoop install -g  tldr
scoop install -g  unzip
scoop install -g  vim
scoop install -g  wget
scoop install -g  cygwin